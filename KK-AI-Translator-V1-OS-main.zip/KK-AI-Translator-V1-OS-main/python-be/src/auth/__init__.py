from .auth import register_auth_check

__all__ = ["register_auth_check"]
